// ComponentReference.jsx
// Screen 4: A lightweight internal reference list of BioSpherix products.
// Not a full catalogue — just enough context for Nihar to select relevant components.

import { useState } from 'react';
import { productReferences } from '../data/data.js';

// ─── PRODUCT IMAGE with fallback ─────────────────────────────────────────────
function ProductImg({ src, alt }) {
  const [error, setError] = useState(false);
  if (error || !src) {
    return <span style={{ fontSize: 12, color: 'var(--muted)', textAlign: 'center' }}>Product image unavailable</span>;
  }
  return (
    <img
      src={src}
      alt={alt}
      style={{ maxHeight: 118, maxWidth: '100%', objectFit: 'contain', display: 'block' }}
      onError={() => setError(true)}
    />
  );
}

// ─── REFERENCE CARD ──────────────────────────────────────────────────────────
function RefCard({ product, onUseInBrief }) {
  return (
    <div className="ref-card">
      {/* Product image */}
      <div className="ref-card-img">
        <ProductImg src={product.image} alt={product.name} />
      </div>

      {/* Card body */}
      <div className="ref-card-body">
        <div className="ref-card-name">{product.name}</div>
        <div className="ref-card-type">{product.type}</div>

        <div className="ref-card-desc">{product.usedFor}</div>

        {/* Dimensions */}
        {product.dimensions && (
          <>
            <div className="ref-card-section-label">Dimensions</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'var(--font-mono)', marginBottom: 6 }}>
              {product.dimensions}
            </div>
          </>
        )}

        {/* Gases supported */}
        <div className="ref-card-section-label">Gases Supported</div>
        <div className="tags-wrap" style={{ marginBottom: 8 }}>
          {product.gasesSupported.map(gas => (
            <span key={gas} className="badge badge-gas">{gas}</span>
          ))}
        </div>

        {/* Good for */}
        <div className="ref-card-section-label">Good For</div>
        <div className="tags-wrap">
          {product.goodFor.map(tag => (
            <span key={tag} className="tag">{tag}</span>
          ))}
        </div>
      </div>

      {/* Footer with action */}
      <div className="ref-card-footer">
        <button
          className="btn btn-secondary btn-sm"
          style={{ width: '100%', justifyContent: 'center' }}
          onClick={() => onUseInBrief(product)}
        >
          Use in Brief
        </button>
      </div>
    </div>
  );
}

// ─── COMPONENT REFERENCE MAIN ─────────────────────────────────────────────────
export default function ComponentReference({ onNewBriefWithProduct }) {
  const [search, setSearch] = useState('');

  // Filter products by search
  const filtered = productReferences.filter(p => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.type.toLowerCase().includes(q) ||
      p.usedFor.toLowerCase().includes(q) ||
      p.gasesSupported.some(g => g.toLowerCase().includes(q)) ||
      p.goodFor.some(t => t.toLowerCase().includes(q))
    );
  });

  function handleUseInBrief(product) {
    onNewBriefWithProduct(product.id);
  }

  return (
    <div className="page-content">
      {/* Page heading */}
      <div style={{ marginBottom: 28 }}>
        <div className="page-title">Component Reference</div>
        <div className="page-subtitle">
          A lightweight reference for BioSpherix products used in custom system designs.
          Use "Use in Brief" to start a new brief with a product pre-selected.
        </div>
      </div>

      {/* Search bar */}
      <div className="toolbar" style={{ marginBottom: 24 }}>
        <div className="search-wrap">
          <svg className="search-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            className="search-input"
            type="text"
            placeholder="Search by product name, type, gas, or application..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        {search && (
          <button className="btn btn-ghost btn-sm" onClick={() => setSearch('')}>
            Clear
          </button>
        )}
      </div>

      {/* Results count */}
      <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 16 }}>
        {filtered.length} of {productReferences.length} products
      </div>

      {/* Reference grid */}
      {filtered.length === 0 ? (
        <div className="empty-state" style={{ padding: '48px 40px' }}>
          <h2>No products match your search</h2>
          <p>Try a different keyword, such as a gas name or application type.</p>
        </div>
      ) : (
        <div className="ref-grid">
          {filtered.map(product => (
            <RefCard
              key={product.id}
              product={product}
              onUseInBrief={handleUseInBrief}
            />
          ))}
        </div>
      )}

      {/* Bottom note */}
      <div style={{ marginTop: 40, padding: '16px 20px', background: 'var(--blue-gray)', borderRadius: 'var(--radius-md)', fontSize: 12, color: 'var(--muted)' }}>
        This reference is for internal workflow use only. For complete product specifications and ordering information, refer to the official BioSpherix product catalogue at biospherix.com.
      </div>
    </div>
  );
}
