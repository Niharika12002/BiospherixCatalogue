// BriefDetail.jsx
// Screen 3: Displays a saved brief as a clean, professional render brief summary.

import { useState } from 'react';
import { productReferences, STATUS_COLORS, PRIORITY_COLORS } from '../data/data.js';

// ─── PRODUCT IMAGE with fallback ─────────────────────────────────────────────
function ProductImg({ src, alt, style }) {
  const [error, setError] = useState(false);
  if (error || !src) {
    return <span style={{ fontSize: 12, color: 'var(--muted)' }}>Product image unavailable</span>;
  }
  return <img src={src} alt={alt} style={style} onError={() => setError(true)} />;
}

// ─── DETAIL ROW ──────────────────────────────────────────────────────────────
function InfoRow({ label, value }) {
  if (!value) return null;
  return (
    <div className="detail-info-row">
      <span className="detail-info-label">{label}</span>
      <span className="detail-info-value">{value}</span>
    </div>
  );
}

// ─── SECTION BLOCK ───────────────────────────────────────────────────────────
function DetailSection({ title, children }) {
  return (
    <div className="section-card" style={{ marginBottom: 16 }}>
      <div className="section-card-header">
        <h3>{title}</h3>
      </div>
      <div className="section-card-body">
        {children}
      </div>
    </div>
  );
}

// ─── GENERATE SYSTEM SUMMARY ─────────────────────────────────────────────────
// Builds a readable paragraph from the brief data, similar to a design brief summary.
function generateSummary(brief) {
  const selectedProducts = (brief.productReferences || [])
    .map(id => productReferences.find(p => p.id === id)?.name)
    .filter(Boolean);

  const gases = (brief.gasesNeeded || []).join(', ') || 'unspecified gases';
  const env = brief.environmentType || 'unspecified environment';
  const app = brief.applicationNeed || 'the specified application';
  const views = (brief.visualNotes?.desiredView || []).join(', ') || 'standard view';
  const renderStyle = brief.visualNotes?.renderStyle || 'standard';
  const constraints = brief.constraints?.dimensions || '';

  const productStr = selectedProducts.length > 0
    ? selectedProducts.join(', ')
    : 'a custom system configuration';

  const constraintStr = constraints
    ? ` Key dimensional constraints include: ${constraints}.`
    : '';

  return `This render brief is for a ${app} system using ${productStr}. The setup should support ${gases} within a ${env} environment.${constraintStr} The render should communicate a ${renderStyle.toLowerCase()} perspective using ${views} view(s), while accounting for the constraints and application requirements described below.`;
}

// ─── BRIEF DETAIL MAIN ───────────────────────────────────────────────────────
export default function BriefDetail({ brief, onEdit, onDuplicate, onDelete, onBack }) {
  const statusStyle = STATUS_COLORS[brief.status] || STATUS_COLORS['New Request'];
  const priorityStyle = PRIORITY_COLORS[brief.priority] || PRIORITY_COLORS['Medium'];

  // Resolve selected product objects
  const selectedProducts = (brief.productReferences || [])
    .map(id => productReferences.find(p => p.id === id))
    .filter(Boolean);

  const formatDate = (dateStr) => {
    if (!dateStr) return '—';
    try {
      return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US', {
        month: 'long', day: 'numeric', year: 'numeric'
      });
    } catch { return dateStr; }
  };

  const handleDelete = () => {
    if (window.confirm(`Delete "${brief.title}"? This cannot be undone.`)) {
      onDelete(brief.id);
    }
  };

  const hasMissingInfo = brief.constraints?.missingInformation?.trim();
  const unresolvedCount = (brief.openQuestions || []).filter(q => q.status === 'unresolved').length;

  return (
    <div className="page-content">
      {/* Back link */}
      <button
        className="btn btn-ghost btn-sm"
        onClick={onBack}
        style={{ marginBottom: 16 }}
      >
        ← Back to Dashboard
      </button>

      {/* Top action bar */}
      <div className="detail-header">
        <div>
          <div className="page-title">{brief.title}</div>
          <div className="page-subtitle">Render Brief</div>
        </div>
        <div className="detail-header-actions">
          <button className="btn btn-ghost btn-sm" onClick={() => window.print()}>
            Print / Export
          </button>
          <button className="btn btn-secondary btn-sm" onClick={() => onDuplicate(brief.id)}>
            Duplicate
          </button>
          <button className="btn btn-danger btn-sm" onClick={handleDelete}>
            Delete
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => onEdit(brief.id)}>
            Edit Brief
          </button>
        </div>
      </div>

      {/* Summary bar (navy background) */}
      <div className="detail-summary-bar">
        <div style={{ flex: 1 }}>
          <h1>{brief.title}</h1>
          <div className="client">{brief.clientName || 'No client specified'}</div>
          <div className="detail-summary-badges">
            <span className="badge" style={{ background: statusStyle.bg, color: statusStyle.text, borderColor: statusStyle.border }}>
              {brief.status}
            </span>
            <span className="badge" style={{ background: priorityStyle.bg, color: priorityStyle.text, borderColor: priorityStyle.border }}>
              {brief.priority} Priority
            </span>
            {brief.applicationNeed && (
              <span className="badge" style={{ background: 'rgba(255,255,255,0.15)', color: 'white', borderColor: 'rgba(255,255,255,0.2)' }}>
                {brief.applicationNeed}
              </span>
            )}
          </div>
        </div>
        <div className="detail-summary-right">
          <div className="detail-deadline-label">Deadline</div>
          <div className="detail-deadline-value">{formatDate(brief.deadline)}</div>
          <div style={{ marginTop: 12 }}>
            <div className="detail-deadline-label">Date Received</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', marginTop: 2 }}>
              {formatDate(brief.dateReceived)}
            </div>
          </div>
        </div>
      </div>

      {/* Missing info callout (shown prominently if present) */}
      {hasMissingInfo && (
        <div className="missing-info-box" style={{ marginBottom: 20 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" style={{ flexShrink: 0, marginTop: 1 }}>
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <div>
            <strong>Missing Information:</strong> {brief.constraints.missingInformation}
          </div>
        </div>
      )}

      {/* Unresolved questions callout */}
      {unresolvedCount > 0 && (
        <div style={{ background: '#FFF3E6', border: '1px solid #F9C899', borderRadius: 'var(--radius-md)', padding: '12px 18px', marginBottom: 20, display: 'flex', gap: 10, alignItems: 'center', fontSize: 13, color: '#B85C00' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" style={{ flexShrink: 0 }}>
            <circle cx="12" cy="12" r="10"/>
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
          </svg>
          <span><strong>{unresolvedCount} unresolved {unresolvedCount === 1 ? 'question' : 'questions'}</strong> — review open questions before starting the render.</span>
        </div>
      )}

      {/* Product image visual area */}
      <DetailSection title="Selected System References">
        {selectedProducts.length === 0 ? (
          <p style={{ color: 'var(--muted)', fontSize: 13 }}>No product image selected. Add a product reference when editing this brief.</p>
        ) : (
          <div className="product-strip">
            {selectedProducts.map(product => (
              <div key={product.id} className="product-strip-card">
                <div className="product-strip-img">
                  <ProductImg
                    src={product.image}
                    alt={product.name}
                    style={{ maxHeight: 80, maxWidth: '100%', objectFit: 'contain' }}
                  />
                </div>
                <div className="product-strip-name">{product.name}</div>
                <div className="product-strip-type">{product.type}</div>
              </div>
            ))}
          </div>
        )}
      </DetailSection>

      {/* System summary paragraph */}
      <DetailSection title="System Summary">
        <div className="system-summary-box">
          {generateSummary(brief)}
        </div>
        {brief.requestSummary && (
          <div style={{ marginTop: 12, fontSize: 13, color: 'var(--text)', lineHeight: 1.65 }}>
            <strong style={{ color: 'var(--navy)' }}>Original Request:</strong> {brief.requestSummary}
          </div>
        )}
      </DetailSection>

      {/* Two-column: Application + Gases */}
      <div className="detail-two-col">
        <DetailSection title="Application Needs">
          <InfoRow label="Application" value={brief.applicationNeed} />
          <InfoRow label="Environment" value={brief.environmentType} />
          {brief.applicationNotes && (
            <div style={{ marginTop: 10, fontSize: 13, color: 'var(--text)', lineHeight: 1.6 }}>
              {brief.applicationNotes}
            </div>
          )}
        </DetailSection>

        <DetailSection title="Gases Needed">
          {brief.gasesNeeded?.length > 0 ? (
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {brief.gasesNeeded.map(gas => (
                <span key={gas} className="badge badge-gas" style={{ fontSize: 13, padding: '5px 12px' }}>
                  {gas}
                </span>
              ))}
            </div>
          ) : (
            <p style={{ color: 'var(--muted)', fontSize: 13 }}>No gases specified.</p>
          )}
        </DetailSection>
      </div>

      {/* Required Components */}
      {brief.componentsNeeded?.length > 0 && (
        <DetailSection title="Required Components">
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {brief.componentsNeeded.map(comp => (
              <span key={comp} className="tag">{comp}</span>
            ))}
          </div>
        </DetailSection>
      )}

      {/* Constraints */}
      <DetailSection title="Constraints">
        <InfoRow label="Dimensions" value={brief.constraints?.dimensions} />
        <InfoRow label="Space Constraints" value={brief.constraints?.spaceConstraints} />
        <InfoRow label="Compatibility" value={brief.constraints?.compatibilityConcerns} />
        <InfoRow label="Gas Range" value={brief.constraints?.requiredGasRange} />
        <InfoRow label="Materials / Cleaning" value={brief.constraints?.materialCleaning} />
        <InfoRow label="Safety" value={brief.constraints?.safetyConciderations} />
      </DetailSection>

      {/* Visual / Render Notes */}
      <DetailSection title="Visual / Render Notes">
        <InfoRow
          label="Desired View(s)"
          value={brief.visualNotes?.desiredView?.join(', ')}
        />
        <InfoRow label="Render Style" value={brief.visualNotes?.renderStyle} />
        {brief.visualNotes?.renderNotes && (
          <div style={{ marginTop: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--navy)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 }}>
              Render Notes
            </div>
            <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.65 }}>
              {brief.visualNotes.renderNotes}
            </div>
          </div>
        )}
        {brief.visualNotes?.referenceImageNotes && (
          <div style={{ marginTop: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--navy)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 }}>
              Reference Image Notes
            </div>
            <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.65 }}>
              {brief.visualNotes.referenceImageNotes}
            </div>
          </div>
        )}
      </DetailSection>

      {/* Open Questions */}
      <DetailSection title="Open Questions">
        {brief.openQuestions?.length === 0 || !brief.openQuestions ? (
          <p style={{ color: 'var(--muted)', fontSize: 13 }}>No open questions logged.</p>
        ) : (
          brief.openQuestions.map(q => (
            <div key={q.id} className="question-row">
              <div className={`q-status-dot ${q.status}`} />
              <span style={{ flex: 1, fontSize: 13, color: 'var(--text)' }}>{q.question}</span>
              <span style={{
                fontSize: 11,
                fontWeight: 600,
                color: q.status === 'answered' ? '#22C55E' : '#F59E0B',
                textTransform: 'capitalize',
              }}>
                {q.status}
              </span>
            </div>
          ))
        )}
      </DetailSection>

      {/* Revision Notes */}
      {brief.revisionNotes?.length > 0 && (
        <DetailSection title="Revision Notes">
          {brief.revisionNotes.map(r => (
            <div key={r.id} className="revision-item">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span className="revision-version">{r.version || '—'}</span>
                <span className="revision-date">{r.date}</span>
              </div>
              <InfoRow label="Feedback" value={r.feedback} />
              <InfoRow label="Change Needed" value={r.changeNeeded} />
            </div>
          ))}
        </DetailSection>
      )}

      {/* Footer actions */}
      <div style={{ display: 'flex', gap: 10, padding: '8px 0 48px', flexWrap: 'wrap' }}>
        <button className="btn btn-ghost" onClick={onBack}>← Back to Dashboard</button>
        <button className="btn btn-secondary" onClick={() => onDuplicate(brief.id)}>Duplicate Brief</button>
        <button className="btn btn-danger" onClick={handleDelete}>Delete Brief</button>
        <button className="btn btn-primary" onClick={() => onEdit(brief.id)}>Edit Brief</button>
      </div>
    </div>
  );
}
