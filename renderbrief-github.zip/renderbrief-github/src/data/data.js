// src/data/data.js
// ─── Single source of truth for all product and form data ────────────────────
// All components import from here. Image paths point to /public/images/.

// ─── PRODUCT REFERENCES ──────────────────────────────────────────────────────

export const productReferences = [
  {
    id: 'c-chamber',
    name: 'C-Chamber',
    type: 'Incubator Subchamber',
    image: '/images/c-chamber.png',
    usedFor:
      'Controlled microenvironment inside existing incubators. Protects cells from room air during door openings or transport.',
    gasesSupported: ['O₂', 'CO₂', 'N₂'],
    goodFor: ['Hypoxia', 'Stem cell studies', 'Reoxygenation', 'Ischemia', 'Tumor microenvironment'],
    description: 'Clear polycarbonate subchamber. Works with most third-party incubators. Available in 1–4 shelf configurations.',
    dimensions: '14"W × 13"D × 5.25"–10"H',
  },
  {
    id: 'proox-p110',
    name: 'ProOx P110',
    type: 'Compact O₂ Controller',
    image: '/images/proox-p110.png',
    usedFor: 'Oxygen control in semi-sealable enclosures. Compact footprint for bench-top and incubator setups.',
    gasesSupported: ['O₂', 'N₂'],
    goodFor: ['Hypoxia', 'Hyperoxia', 'Oxygen-sensitive workflows'],
    description: 'Entry-level O₂ controller. Closed-loop O₂ control 0.1–99.9%.',
    dimensions: 'Compact, 12 VDC',
  },
  {
    id: 'proox-p360',
    name: 'ProOx P360',
    type: 'High-Infusion O₂ Controller',
    image: '/images/proox-p360.png',
    usedFor: 'Oxygen control in larger or higher-demand enclosures requiring faster gas infusion rates.',
    gasesSupported: ['O₂', 'N₂'],
    goodFor: ['Larger chambers', 'High infusion needs', 'Hypoxia', 'Hyperoxia'],
    description: 'High-infusion-rate O₂ controller. For larger enclosures or rapid gas transitions.',
    dimensions: '12 VDC, higher flow capacity',
  },
  {
    id: 'proco2-p120',
    name: 'ProCO₂ P120',
    type: 'Compact CO₂ Controller',
    image: '/images/proco2-p120.png',
    usedFor: 'Carbon dioxide control in semi-sealable enclosures. Flexible integration across a wide range of systems.',
    gasesSupported: ['CO₂', 'N₂'],
    goodFor: ['CO₂-sensitive applications', 'Hypercapnia', 'Acidosis'],
    description: 'Compact CO₂ controller. Control range 0.1–20.0% CO₂ (±0.3–0.7%).',
    dimensions: '4⅜"H × 8⅞"W × 9"D, 3.9 lbs',
  },
  {
    id: 'proox-c21',
    name: 'ProOx C21',
    type: 'Compact O₂ & CO₂ Controller',
    image: '/images/proox-c21.png',
    usedFor: 'Dual gas control for oxygen and carbon dioxide. Works with bench-top incubators and C-Chamber systems.',
    gasesSupported: ['O₂', 'CO₂', 'N₂'],
    goodFor: ['Physiologic control', 'C-Chamber workflows', 'Incubator upgrades'],
    description: 'Dual-gas controller. O₂ 0.1–99.9% and CO₂ 0.1–20.0%. Infusion: 1–14 SCFH.',
    dimensions: '4⅜"H × 8⅞"W × 9"D, 4.7 lbs',
  },
  {
    id: 'oxycycler-c42',
    name: 'OxyCycler C42',
    type: 'Dynamic O₂ & CO₂ Controller',
    image: '/images/oxycycler-c42.png',
    usedFor: 'Dynamic gas cycling and programmable conditions. Multiple setpoints, ranges, and cycle counts.',
    gasesSupported: ['O₂', 'CO₂', 'N₂'],
    goodFor: ['Chronic intermittent hypoxia', 'Dynamic cycling', 'Multiple setpoints', 'Sleep apnea models'],
    description: 'Dual-channel dynamic controller. Controls multiple chambers simultaneously.',
    dimensions: '8⅓"H × 12¾"W × 14½"D, 17 lbs',
  },
  {
    id: 'oxystreamer',
    name: 'OxyStreamer',
    type: 'Live Cell Microscopy Controller',
    image: '/images/oxystreamer.png',
    usedFor: 'Conditioning gas streams for microscopy environments and dissolved O₂/CO₂ in media or perfusate.',
    gasesSupported: ['O₂', 'CO₂', 'N₂'],
    goodFor: ['Live cell microscopy', 'Developmental biology', 'Toxicology', 'Media conditioning'],
    description: 'Two identical gas streams without premixed cylinders. O₂ 0.1–99.9%, CO₂ 0.1–20.0%.',
    dimensions: '13"H × 9.3"W × 14.2"D, 10 lbs',
  },
  {
    id: 'oxycycler-gt-series',
    name: 'OxyCycler GT Series',
    type: 'Gasotransmitter Control System',
    image: '/images/oxycycler-gt-series.png',
    usedFor: 'Advanced gas control including O₂, CO₂, RH, and optional gasotransmitters CO and NO.',
    gasesSupported: ['O₂', 'CO₂', 'RH', 'CO', 'NO', 'N₂'],
    goodFor: ['Gasotransmitter workflows', 'Advanced physiology', 'Pathophysiology', 'CO/NO research'],
    description: 'GT41 handles O₂/CO₂/RH. GT4181C adds CO (0–400 ppm). GT4181N adds NO (0–50 ppm). GT4181CN combines both.',
    dimensions: '9"H × 17"W × 17"D per controller, 22 lbs',
  },
]

// ─── FORM OPTIONS ─────────────────────────────────────────────────────────────

export const STATUS_OPTIONS = [
  'New Request',
  'In Progress',
  'Waiting for Info',
  'Ready to Render',
  'Completed',
]

export const PRIORITY_OPTIONS = ['Low', 'Medium', 'High', 'Urgent']

export const APPLICATION_NEEDS = [
  'Hypoxia',
  'Hyperoxia',
  'CO₂ Control',
  'O₂ + CO₂ Control',
  'Live Cell Microscopy',
  'Dynamic Cycling',
  'Gasotransmitter Control',
  'Custom / Other',
]

export const GAS_OPTIONS = ['O₂', 'CO₂', 'N₂', 'CO', 'NO', 'RH']

export const ENVIRONMENT_TYPES = [
  'Incubator',
  'Chamber',
  'Glovebox',
  'Microscope stage',
  'Custom enclosure',
  'Other',
]

export const COMPONENT_OPTIONS = [
  'Chamber body',
  'Controller',
  'Shelf trays',
  'Sensor pod',
  'Tubing',
  'Adapter plate',
  'Gas supply inputs',
  'Monitor pod',
  'Calibration gas connection',
  'External software/control',
  'Power supply',
  'Custom enclosure',
  'Other accessories',
]

export const VIEW_OPTIONS = ['Front', 'Side', 'Back', 'Top', 'Isometric', 'Exploded view']

export const RENDER_STYLES = ['Technical', 'Presentation', 'Realistic', 'Diagrammatic']

// ─── STATUS / PRIORITY COLOR MAP ─────────────────────────────────────────────

export const STATUS_COLORS = {
  'New Request':      { bg: '#EEF4F8', text: '#17233C', border: '#BDD0DE' },
  'In Progress':      { bg: '#FFF3E6', text: '#B85C00', border: '#F9C899' },
  'Waiting for Info': { bg: '#FFF8E1', text: '#8A6300', border: '#FFE082' },
  'Ready to Render':  { bg: '#E8F5E9', text: '#2E7D32', border: '#A5D6A7' },
  'Completed':        { bg: '#F3E5F5', text: '#6A1B9A', border: '#CE93D8' },
}

export const PRIORITY_COLORS = {
  Low:    { bg: '#F7F8FA', text: '#6B7280', border: '#D1D5DB' },
  Medium: { bg: '#EEF4F8', text: '#17233C', border: '#BDD0DE' },
  High:   { bg: '#FFF3E6', text: '#B85C00', border: '#F9C899' },
  Urgent: { bg: '#FEECEC', text: '#B91C1C', border: '#FCA5A5' },
}

// ─── SAMPLE BRIEFS ────────────────────────────────────────────────────────────
// Loaded only when localStorage is empty — keeps the app from being blank on first open.

export const sampleBriefs = [
  {
    id: 'sample-001',
    title: 'Hypoxia Chamber — University Research Lab',
    clientName: 'Dr. Chen, Stanford',
    dateReceived: '2025-05-01',
    deadline: '2025-06-15',
    priority: 'High',
    status: 'In Progress',
    requestSummary:
      'Client needs a compact hypoxia system for stem cell studies inside an existing Thermo Fisher incubator. Must support O₂ range 1–5%. Two shelf capacity required.',
    applicationNeed: 'Hypoxia',
    gasesNeeded: ['O₂', 'N₂'],
    environmentType: 'Incubator',
    applicationNotes:
      'Existing incubator is a Thermo Fisher Heracell 150i. Client wants to avoid buying a new standalone hypoxia workstation.',
    productReferences: ['c-chamber', 'proox-c21'],
    componentsNeeded: ['Chamber body', 'Controller', 'Shelf trays', 'Sensor pod', 'Tubing', 'Gas supply inputs'],
    constraints: {
      dimensions: '14"W × 13"D max — must fit inside Heracell 150i',
      spaceConstraints: 'Controller must sit on shelf above incubator.',
      compatibilityConcerns: 'Client has existing N₂ dewar on site.',
      requiredGasRange: 'O₂: 1–5%. CO₂: 5% (incubator handles CO₂ separately)',
      materialCleaning: 'Stainless steel or polycarbonate preferred.',
      safetyConsiderations: 'N₂ asphyxiation risk. Room ventilation must be confirmed.',
      missingInformation: 'Exact shelf dimensions not confirmed. Need incubator model sheet from client.',
    },
    visualNotes: {
      desiredView: ['Isometric', 'Front'],
      renderStyle: 'Presentation',
      renderNotes: 'Show chamber inside incubator with controller on top. Show gas line routing.',
      referenceImageNotes: 'Client provided a photo of their bench setup.',
    },
    openQuestions: [
      { id: 'q1', question: 'Confirm exact shelf dimensions inside Heracell 150i.', status: 'unresolved' },
      { id: 'q2', question: 'Does client need humidity control in addition to O₂?', status: 'unresolved' },
      { id: 'q3', question: 'Expected number of door openings per day?', status: 'answered' },
    ],
    revisionNotes: [],
    createdAt: '2025-05-01T09:00:00Z',
    updatedAt: '2025-05-10T14:30:00Z',
  },
  {
    id: 'sample-002',
    title: 'Live Cell Microscopy Setup — Pharma Client',
    clientName: 'Meridian Pharma',
    dateReceived: '2025-04-20',
    deadline: '2025-05-30',
    priority: 'Urgent',
    status: 'Waiting for Info',
    requestSummary:
      'Gas conditioning system for a Zeiss LSM 900 microscope stage. O₂ and CO₂ control for real-time imaging of cancer cell migration.',
    applicationNeed: 'Live Cell Microscopy',
    gasesNeeded: ['O₂', 'CO₂', 'N₂'],
    environmentType: 'Microscope stage',
    applicationNotes:
      'Zeiss LSM 900 confocal. 5% CO₂, 21% O₂ baseline with option to drop O₂ to 1% during experiment.',
    productReferences: ['oxystreamer'],
    componentsNeeded: ['Controller', 'Tubing', 'Gas supply inputs', 'Sensor pod'],
    constraints: {
      dimensions: 'OxyStreamer on adjacent cart. ~24" clearance.',
      spaceConstraints: 'Climate-controlled room. No heavy gas bottles inside.',
      compatibilityConcerns: 'Gas lines must run through wall pass-through.',
      requiredGasRange: 'O₂: 1–21%. CO₂: 5%.',
      materialCleaning: 'Standard lab grade.',
      safetyConsiderations: 'Gas line routing through wall requires facilities approval.',
      missingInformation: 'Wall pass-through diameter not confirmed. Facilities contact needed.',
    },
    visualNotes: {
      desiredView: ['Front', 'Side'],
      renderStyle: 'Technical',
      renderNotes: 'Show OxyStreamer with tubing routing to microscope stage. Label all connections.',
      referenceImageNotes: 'Zeiss microscope photo provided by client.',
    },
    openQuestions: [
      { id: 'q1', question: 'Confirm wall pass-through diameter with facilities.', status: 'unresolved' },
      { id: 'q2', question: 'Stage-top incubator or open dish setup?', status: 'unresolved' },
    ],
    revisionNotes: [
      {
        id: 'r1',
        version: 'v1.0',
        date: '2025-04-25',
        feedback: 'Client reviewed initial concept. Requested gas line routing shown more clearly.',
        changeNeeded: 'Update render to show wall pass-through routing with labeled distances.',
      },
    ],
    createdAt: '2025-04-20T10:00:00Z',
    updatedAt: '2025-04-28T16:00:00Z',
  },
  {
    id: 'sample-003',
    title: 'GT Series — CO/NO Gasotransmitter Study',
    clientName: 'Biosciences Dept, MIT',
    dateReceived: '2025-03-15',
    deadline: '2025-04-30',
    priority: 'Medium',
    status: 'Ready to Render',
    requestSummary:
      'Research group studying combined CO and NO gasotransmitter effects on cardiac cells. OxyCycler GT system with combined CO+NO capability.',
    applicationNeed: 'Gasotransmitter Control',
    gasesNeeded: ['O₂', 'CO₂', 'CO', 'NO', 'N₂'],
    environmentType: 'Chamber',
    applicationNotes:
      'GT4181CN configuration. 72-hour continuous exposures. CO target: 100 ppm. NO target: 20 ppm.',
    productReferences: ['oxycycler-gt-series', 'c-chamber'],
    componentsNeeded: ['Chamber body', 'Controller', 'Monitor pod', 'Calibration gas connection', 'Gas supply inputs', 'Sensor pod', 'Tubing'],
    constraints: {
      dimensions: 'Standard GT Series footprint. Cart-mounted preferred.',
      spaceConstraints: 'Dedicated lab room with fume control.',
      compatibilityConcerns: 'CO and NO require specialized gas handling and calibration.',
      requiredGasRange: 'CO: 0–400 ppm, NO: 0–50 ppm, O₂: 5–21%, CO₂: 5%.',
      materialCleaning: 'Stainless steel, CO/NO resistant materials required.',
      safetyConsiderations: 'CO and NO are toxic. Dedicated exhaust, alarms, and leak detection required.',
      missingInformation: '',
    },
    visualNotes: {
      desiredView: ['Isometric', 'Front', 'Side'],
      renderStyle: 'Presentation',
      renderNotes: 'Show complete system: GT controller, C-Chamber, gas lines, monitor pod on cart.',
      referenceImageNotes: '',
    },
    openQuestions: [
      { id: 'q1', question: 'Confirm exhaust system capacity with facilities.', status: 'answered' },
    ],
    revisionNotes: [
      {
        id: 'r1',
        version: 'v1.0',
        date: '2025-03-22',
        feedback: 'Initial layout approved. Add cart dimensions and cable management.',
        changeNeeded: 'Add cart with cable management to render.',
      },
      {
        id: 'r2',
        version: 'v1.1',
        date: '2025-04-10',
        feedback: 'Cart added. Client wants calibration gas connections labeled.',
        changeNeeded: 'Label cal gas fittings on all controllers.',
      },
    ],
    createdAt: '2025-03-15T08:00:00Z',
    updatedAt: '2025-04-15T11:00:00Z',
  },
]
