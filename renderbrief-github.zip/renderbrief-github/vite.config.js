import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// IMPORTANT: Set 'base' to match your GitHub repository name.
// Example: if your repo URL is https://github.com/yourname/renderbrief
// then base should be '/renderbrief/'
//
// If you rename your repo, update this value to match.
export default defineConfig({
  plugins: [react()],
  base: '/renderbrief/',
})
