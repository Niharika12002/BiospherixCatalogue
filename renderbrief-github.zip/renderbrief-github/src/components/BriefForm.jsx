// BriefForm.jsx
// Screen 2: Guided form to create or edit a render brief.
// Organized into labeled sections (A–H) matching the spec.

import { useState } from 'react';
import {
  productReferences,
  STATUS_OPTIONS,
  PRIORITY_OPTIONS,
  APPLICATION_NEEDS,
  GAS_OPTIONS,
  ENVIRONMENT_TYPES,
  COMPONENT_OPTIONS,
  VIEW_OPTIONS,
  RENDER_STYLES,
} from '../data/data.js';

// ─── PRODUCT IMAGE with error fallback ──────────────────────────────────────
function ProductImg({ src, alt }) {
  const [error, setError] = useState(false);
  if (error || !src) return <span style={{ fontSize: 11, color: 'var(--muted)' }}>Image unavailable</span>;
  return <img src={src} alt={alt} style={{ maxHeight: 60, maxWidth: '100%', objectFit: 'contain' }} onError={() => setError(true)} />;
}

// ─── SECTION WRAPPER ─────────────────────────────────────────────────────────
function FormSection({ number, title, children }) {
  return (
    <div className="section-card">
      <div className="section-card-header">
        <div className="section-num">{number}</div>
        <h3>{title}</h3>
      </div>
      <div className="section-card-body">
        {children}
      </div>
    </div>
  );
}

// ─── EMPTY BRIEF TEMPLATE ────────────────────────────────────────────────────
function emptyBrief() {
  return {
    title: '',
    clientName: '',
    dateReceived: new Date().toISOString().slice(0, 10),
    deadline: '',
    priority: 'Medium',
    status: 'New Request',
    requestSummary: '',
    applicationNeed: '',
    gasesNeeded: [],
    environmentType: '',
    applicationNotes: '',
    productReferences: [],
    componentsNeeded: [],
    constraints: {
      dimensions: '',
      spaceConstraints: '',
      compatibilityConcerns: '',
      requiredGasRange: '',
      materialCleaning: '',
      safetyConciderations: '',
      missingInformation: '',
    },
    visualNotes: {
      desiredView: [],
      renderStyle: '',
      renderNotes: '',
      referenceImageNotes: '',
    },
    openQuestions: [],
    revisionNotes: [],
  };
}

// ─── MAIN FORM COMPONENT ─────────────────────────────────────────────────────
export default function BriefForm({ initialData, onSave, onCancel }) {
  // Initialize form state from existing brief or blank template
  const [form, setForm] = useState(() => {
    if (initialData) return { ...emptyBrief(), ...initialData };
    return emptyBrief();
  });

  // New question being typed
  const [newQuestion, setNewQuestion] = useState('');

  // New revision note being typed
  const [newRevision, setNewRevision] = useState({ version: '', date: '', feedback: '', changeNeeded: '' });

  // ── Generic field updater
  function setField(field, value) {
    setForm(prev => ({ ...prev, [field]: value }));
  }

  // ── Nested field updater (constraints, visualNotes)
  function setNestedField(parent, field, value) {
    setForm(prev => ({ ...prev, [parent]: { ...prev[parent], [field]: value } }));
  }

  // ── Toggle item in an array field (gases, components, views)
  function toggleArray(field, value) {
    setForm(prev => {
      const arr = prev[field] || [];
      return {
        ...prev,
        [field]: arr.includes(value) ? arr.filter(v => v !== value) : [...arr, value],
      };
    });
  }

  function toggleNestedArray(parent, field, value) {
    setForm(prev => {
      const arr = prev[parent][field] || [];
      return {
        ...prev,
        [parent]: {
          ...prev[parent],
          [field]: arr.includes(value) ? arr.filter(v => v !== value) : [...arr, value],
        },
      };
    });
  }

  // ── Toggle product reference selection
  function toggleProduct(productId) {
    setForm(prev => {
      const refs = prev.productReferences || [];
      return {
        ...prev,
        productReferences: refs.includes(productId)
          ? refs.filter(id => id !== productId)
          : [...refs, productId],
      };
    });
  }

  // ── Add a new open question
  function addQuestion() {
    if (!newQuestion.trim()) return;
    const q = { id: 'q-' + Date.now(), question: newQuestion.trim(), status: 'unresolved' };
    setForm(prev => ({ ...prev, openQuestions: [...(prev.openQuestions || []), q] }));
    setNewQuestion('');
  }

  function removeQuestion(id) {
    setForm(prev => ({ ...prev, openQuestions: prev.openQuestions.filter(q => q.id !== id) }));
  }

  function toggleQuestionStatus(id) {
    setForm(prev => ({
      ...prev,
      openQuestions: prev.openQuestions.map(q =>
        q.id === id ? { ...q, status: q.status === 'unresolved' ? 'answered' : 'unresolved' } : q
      ),
    }));
  }

  // ── Add a revision note
  function addRevision() {
    if (!newRevision.feedback.trim()) return;
    const r = { id: 'r-' + Date.now(), ...newRevision };
    setForm(prev => ({ ...prev, revisionNotes: [...(prev.revisionNotes || []), r] }));
    setNewRevision({ version: '', date: '', feedback: '', changeNeeded: '' });
  }

  function removeRevision(id) {
    setForm(prev => ({ ...prev, revisionNotes: prev.revisionNotes.filter(r => r.id !== id) }));
  }

  // ── Save handler
  function handleSave() {
    if (!form.title.trim()) {
      alert('Please enter a brief title before saving.');
      return;
    }
    onSave(form);
  }

  // ── Reset form
  function handleReset() {
    if (window.confirm('Reset all form fields? This cannot be undone.')) {
      setForm(emptyBrief());
    }
  }

  const isEditing = !!initialData?.id;

  return (
    <div className="page-content">
      {/* Page header */}
      <div className="form-page-header">
        <div>
          <div className="page-title">{isEditing ? 'Edit Brief' : 'New Render Brief'}</div>
          <div className="page-subtitle">
            {isEditing ? `Editing: ${initialData.title}` : 'Fill out the sections below to build a complete design brief.'}
          </div>
        </div>
        <div className="form-page-actions">
          <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
          <button className="btn btn-secondary" onClick={handleReset}>Reset Form</button>
          <button className="btn btn-primary" onClick={handleSave}>Save Brief</button>
        </div>
      </div>

      {/* A. Request Overview */}
      <FormSection number="A" title="Request Overview">
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Brief Title *</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. Hypoxia Chamber — University Research Lab"
              value={form.title}
              onChange={e => setField('title', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Client / Request Name</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. Dr. Chen, Stanford"
              value={form.clientName}
              onChange={e => setField('clientName', e.target.value)}
            />
          </div>
        </div>
        <div className="form-row-3">
          <div className="form-group">
            <label className="form-label">Date Received</label>
            <input
              className="form-input"
              type="date"
              value={form.dateReceived}
              onChange={e => setField('dateReceived', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Deadline</label>
            <input
              className="form-input"
              type="date"
              value={form.deadline}
              onChange={e => setField('deadline', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Priority</label>
            <select className="form-select" value={form.priority} onChange={e => setField('priority', e.target.value)}>
              {PRIORITY_OPTIONS.map(p => <option key={p}>{p}</option>)}
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Status</label>
            <select className="form-select" value={form.status} onChange={e => setField('status', e.target.value)}>
              {STATUS_OPTIONS.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Request Summary</label>
          <textarea
            className="form-textarea"
            rows={3}
            placeholder="Describe the client's request in plain language. What do they need and why?"
            value={form.requestSummary}
            onChange={e => setField('requestSummary', e.target.value)}
          />
        </div>
      </FormSection>

      {/* B. Application Needs */}
      <FormSection number="B" title="Application Needs">
        <div className="form-group">
          <label className="form-label">Main Application Need</label>
          <div className="radio-group">
            {APPLICATION_NEEDS.map(need => (
              <span
                key={need}
                className={`radio-pill${form.applicationNeed === need ? ' selected' : ''}`}
                onClick={() => setField('applicationNeed', need)}
              >
                {need}
              </span>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Gases Needed</label>
          <div className="checkbox-grid">
            {GAS_OPTIONS.map(gas => (
              <label
                key={gas}
                className={`checkbox-pill${form.gasesNeeded.includes(gas) ? ' checked' : ''}`}
              >
                <input
                  type="checkbox"
                  checked={form.gasesNeeded.includes(gas)}
                  onChange={() => toggleArray('gasesNeeded', gas)}
                />
                {gas}
              </label>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Environment Type</label>
          <div className="radio-group">
            {ENVIRONMENT_TYPES.map(env => (
              <span
                key={env}
                className={`radio-pill${form.environmentType === env ? ' selected' : ''}`}
                onClick={() => setField('environmentType', env)}
              >
                {env}
              </span>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Notes About Application</label>
          <textarea
            className="form-textarea"
            rows={3}
            placeholder="Any additional context about the application, experiment, or workflow..."
            value={form.applicationNotes}
            onChange={e => setField('applicationNotes', e.target.value)}
          />
        </div>
      </FormSection>

      {/* C. Product / System References */}
      <FormSection number="C" title="Product / System References">
        <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 16 }}>
          Select the BioSpherix products relevant to this design request. These serve as a lightweight reference, not a full specification.
        </p>
        <div className="product-selector-grid">
          {productReferences.map(product => {
            const isSelected = form.productReferences.includes(product.id);
            return (
              <div
                key={product.id}
                className={`product-select-card${isSelected ? ' selected' : ''}`}
                onClick={() => toggleProduct(product.id)}
              >
                <div className="product-select-img">
                  <ProductImg src={product.image} alt={product.name} />
                </div>
                <div className="product-select-name">
                  {product.name}
                  {isSelected && <span className="selected-check">✓</span>}
                </div>
                <div className="product-select-type">{product.type}</div>
              </div>
            );
          })}
          {/* Other / Custom option */}
          <div
            className={`product-select-card${form.productReferences.includes('other') ? ' selected' : ''}`}
            onClick={() => toggleProduct('other')}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 120 }}
          >
            <div style={{ fontSize: 28, marginBottom: 8, color: 'var(--muted)' }}>＋</div>
            <div className="product-select-name">
              Other / Custom
              {form.productReferences.includes('other') && <span className="selected-check">✓</span>}
            </div>
            <div className="product-select-type">Custom system or component</div>
          </div>
        </div>
      </FormSection>

      {/* D. Components Needed */}
      <FormSection number="D" title="Components Needed">
        <div className="checkbox-grid">
          {COMPONENT_OPTIONS.map(comp => (
            <label
              key={comp}
              className={`checkbox-pill${form.componentsNeeded.includes(comp) ? ' checked' : ''}`}
            >
              <input
                type="checkbox"
                checked={form.componentsNeeded.includes(comp)}
                onChange={() => toggleArray('componentsNeeded', comp)}
              />
              {comp}
            </label>
          ))}
        </div>
      </FormSection>

      {/* E. Constraints */}
      <FormSection number="E" title="Constraints">
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Approximate Size / Dimensions</label>
            <input
              className="form-input"
              type="text"
              placeholder='e.g. 14"W × 13"D, must fit inside Heracell 150i'
              value={form.constraints.dimensions}
              onChange={e => setNestedField('constraints', 'dimensions', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Space Constraints</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. Controller must sit on shelf above incubator"
              value={form.constraints.spaceConstraints}
              onChange={e => setNestedField('constraints', 'spaceConstraints', e.target.value)}
            />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Compatibility Concerns</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. Must be compatible with existing N₂ dewar"
              value={form.constraints.compatibilityConcerns}
              onChange={e => setNestedField('constraints', 'compatibilityConcerns', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Required Gas Range</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. O₂: 1–5%, CO₂: 5%"
              value={form.constraints.requiredGasRange}
              onChange={e => setNestedField('constraints', 'requiredGasRange', e.target.value)}
            />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Material / Cleaning Concerns</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. Stainless steel preferred, easy wipe-down"
              value={form.constraints.materialCleaning}
              onChange={e => setNestedField('constraints', 'materialCleaning', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Safety Considerations</label>
            <input
              className="form-input"
              type="text"
              placeholder="e.g. N₂ asphyxiation risk, room ventilation required"
              value={form.constraints.safetyConciderations}
              onChange={e => setNestedField('constraints', 'safetyConciderations', e.target.value)}
            />
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Missing Information</label>
          <textarea
            className="form-textarea"
            rows={2}
            placeholder="What information is still needed before the render can begin?"
            value={form.constraints.missingInformation}
            onChange={e => setNestedField('constraints', 'missingInformation', e.target.value)}
          />
        </div>
      </FormSection>

      {/* F. Visual / Render Notes */}
      <FormSection number="F" title="Visual / Render Notes">
        <div className="form-group">
          <label className="form-label">Desired View</label>
          <div className="checkbox-grid">
            {VIEW_OPTIONS.map(view => (
              <label
                key={view}
                className={`checkbox-pill${form.visualNotes.desiredView?.includes(view) ? ' checked' : ''}`}
              >
                <input
                  type="checkbox"
                  checked={form.visualNotes.desiredView?.includes(view)}
                  onChange={() => toggleNestedArray('visualNotes', 'desiredView', view)}
                />
                {view}
              </label>
            ))}
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Render Style</label>
          <div className="radio-group">
            {RENDER_STYLES.map(style => (
              <span
                key={style}
                className={`radio-pill${form.visualNotes.renderStyle === style ? ' selected' : ''}`}
                onClick={() => setNestedField('visualNotes', 'renderStyle', style)}
              >
                {style}
              </span>
            ))}
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Notes for 3D Render</label>
            <textarea
              className="form-textarea"
              rows={3}
              placeholder="Describe what the render should communicate, show, or highlight..."
              value={form.visualNotes.renderNotes}
              onChange={e => setNestedField('visualNotes', 'renderNotes', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Reference Image Notes</label>
            <textarea
              className="form-textarea"
              rows={3}
              placeholder="Describe any reference images, angles, or examples to follow..."
              value={form.visualNotes.referenceImageNotes}
              onChange={e => setNestedField('visualNotes', 'referenceImageNotes', e.target.value)}
            />
          </div>
        </div>
      </FormSection>

      {/* G. Open Questions */}
      <FormSection number="G" title="Open Questions">
        <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 14 }}>
          Track questions that still need answers before the render can proceed.
        </p>

        {/* Existing questions */}
        {form.openQuestions.map(q => (
          <div key={q.id} className="question-list-item">
            <div
              className={`q-status-dot ${q.status}`}
              style={{ cursor: 'pointer', marginTop: 3 }}
              title={`Click to mark as ${q.status === 'unresolved' ? 'answered' : 'unresolved'}`}
              onClick={() => toggleQuestionStatus(q.id)}
            />
            <span className="q-text">{q.question}</span>
            <span style={{ fontSize: 11, color: 'var(--muted)', whiteSpace: 'nowrap' }}>
              {q.status}
            </span>
            <button className="remove-btn" onClick={() => removeQuestion(q.id)} title="Remove">×</button>
          </div>
        ))}

        {/* Add new question */}
        <div className="question-input-row">
          <input
            className="form-input"
            type="text"
            placeholder="Add an open question..."
            value={newQuestion}
            onChange={e => setNewQuestion(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addQuestion()}
            style={{ flex: 1 }}
          />
          <button className="btn btn-secondary" onClick={addQuestion}>Add</button>
        </div>
      </FormSection>

      {/* H. Revision Notes */}
      <FormSection number="H" title="Revision Notes">
        <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 14 }}>
          Log client feedback and changes needed after each review cycle.
        </p>

        {/* Existing revisions */}
        {form.revisionNotes.map(r => (
          <div key={r.id} className="revision-item">
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8, gap: 8 }}>
              <span className="revision-version">{r.version || 'v?'}</span>
              <span className="revision-date">{r.date}</span>
              <button className="remove-btn" onClick={() => removeRevision(r.id)} title="Remove" style={{ marginLeft: 'auto' }}>×</button>
            </div>
            <div style={{ fontSize: 13, marginBottom: 4 }}><strong>Feedback:</strong> {r.feedback}</div>
            {r.changeNeeded && <div style={{ fontSize: 13, color: 'var(--muted)' }}><strong>Change needed:</strong> {r.changeNeeded}</div>}
          </div>
        ))}

        {/* Add new revision */}
        <div style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: 16 }}>
          <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--navy)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>
            Add Revision Note
          </p>
          <div className="form-row">
            <div className="form-group" style={{ marginBottom: 12 }}>
              <label className="form-label">Version Label</label>
              <input
                className="form-input"
                type="text"
                placeholder="e.g. v1.0, v2.1"
                value={newRevision.version}
                onChange={e => setNewRevision(r => ({ ...r, version: e.target.value }))}
              />
            </div>
            <div className="form-group" style={{ marginBottom: 12 }}>
              <label className="form-label">Date</label>
              <input
                className="form-input"
                type="date"
                value={newRevision.date}
                onChange={e => setNewRevision(r => ({ ...r, date: e.target.value }))}
              />
            </div>
          </div>
          <div className="form-group" style={{ marginBottom: 12 }}>
            <label className="form-label">Client Feedback</label>
            <textarea
              className="form-textarea"
              rows={2}
              placeholder="What feedback did the client provide?"
              value={newRevision.feedback}
              onChange={e => setNewRevision(r => ({ ...r, feedback: e.target.value }))}
            />
          </div>
          <div className="form-group" style={{ marginBottom: 12 }}>
            <label className="form-label">Change Needed</label>
            <input
              className="form-input"
              type="text"
              placeholder="What needs to change in the next version?"
              value={newRevision.changeNeeded}
              onChange={e => setNewRevision(r => ({ ...r, changeNeeded: e.target.value }))}
            />
          </div>
          <button className="btn btn-secondary btn-sm" onClick={addRevision}>
            + Add Revision Note
          </button>
        </div>
      </FormSection>

      {/* Bottom action bar */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, padding: '8px 0 40px' }}>
        <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn btn-secondary" onClick={handleReset}>Reset Form</button>
        <button className="btn btn-primary btn-lg" onClick={handleSave}>Save Brief</button>
      </div>
    </div>
  );
}
