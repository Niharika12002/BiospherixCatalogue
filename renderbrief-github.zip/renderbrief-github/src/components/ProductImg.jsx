import { useState } from 'react'

/**
 * ProductImg
 * Renders a product image with a clean fallback message if the file is missing.
 * Image files live in /public/images/ — see README for filenames.
 */
export default function ProductImg({ image, name, style = {} }) {
  const [error, setError] = useState(false)

  if (error) {
    return (
      <span
        style={{
          fontSize: 11,
          color: '#9CA3AF',
          padding: '8px 4px',
          display: 'block',
          textAlign: 'center',
        }}
      >
        Product image unavailable
      </span>
    )
  }

  return (
    <img
      src={image}
      alt={name}
      onError={() => setError(true)}
      style={style}
    />
  )
}
