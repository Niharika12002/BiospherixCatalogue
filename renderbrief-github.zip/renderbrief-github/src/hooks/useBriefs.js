// useBriefs.js
// Custom hook to manage all brief state and localStorage persistence.
// All CRUD operations for briefs live here so components stay clean.

import { useState, useEffect } from 'react';
import { sampleBriefs } from '../data/data.js';

const STORAGE_KEY = 'renderbrief_briefs';

// Generate a simple unique ID
function generateId() {
  return 'brief-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
}

export function useBriefs() {
  const [briefs, setBriefs] = useState(() => {
    // Load from localStorage on first render
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
      // If nothing in storage, seed with sample data for demo
      return sampleBriefs;
    } catch {
      return sampleBriefs;
    }
  });

  // Persist to localStorage whenever briefs change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(briefs));
  }, [briefs]);

  // Add a new brief
  function addBrief(briefData) {
    const now = new Date().toISOString();
    const newBrief = {
      ...briefData,
      id: generateId(),
      createdAt: now,
      updatedAt: now,
    };
    setBriefs(prev => [newBrief, ...prev]);
    return newBrief.id;
  }

  // Update an existing brief
  function updateBrief(id, briefData) {
    setBriefs(prev =>
      prev.map(b =>
        b.id === id
          ? { ...b, ...briefData, id, updatedAt: new Date().toISOString() }
          : b
      )
    );
  }

  // Delete a brief by ID
  function deleteBrief(id) {
    setBriefs(prev => prev.filter(b => b.id !== id));
  }

  // Duplicate a brief — copies it with a new ID and "New Request" status
  function duplicateBrief(id) {
    const source = briefs.find(b => b.id === id);
    if (!source) return null;
    const now = new Date().toISOString();
    const copy = {
      ...source,
      id: generateId(),
      title: source.title + ' (Copy)',
      status: 'New Request',
      createdAt: now,
      updatedAt: now,
    };
    setBriefs(prev => [copy, ...prev]);
    return copy.id;
  }

  // Get a single brief by ID
  function getBrief(id) {
    return briefs.find(b => b.id === id) || null;
  }

  return { briefs, addBrief, updateBrief, deleteBrief, duplicateBrief, getBrief };
}
