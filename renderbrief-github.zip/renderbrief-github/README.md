# RenderBrief

**A custom machine render brief builder for Nihar's BioSpherix design workflow.**

RenderBrief is an internal tool that turns scattered client requests into clean, organized design briefs — ready to reference when starting a 3D render or system design.

Live at: `https://YOUR-GITHUB-USERNAME.github.io/renderbrief/`

---

## Deploying to GitHub Pages (Online — No Local Setup Needed)

### Step 1: Create a new repository on GitHub

1. Go to [github.com](https://github.com) and sign in
2. Click **New repository** (the green button or the + icon)
3. Name it exactly: `renderbrief`
4. Set it to **Public**
5. Do **not** add a README, .gitignore, or license (we already have them)
6. Click **Create repository**

### Step 2: Upload the files

1. On your new empty repository page, click **uploading an existing file**
2. Drag and drop **all the files and folders** from this zip into the upload area
   - You must upload the folder structure, not just the files
   - GitHub allows folder drag-and-drop — drag the whole `src/` folder, `.github/` folder, etc.
3. Add a commit message like `Initial upload`
4. Click **Commit changes**

> **Important:** You need to upload the `.github/workflows/deploy.yml` file for auto-deploy to work.
> GitHub may hide dotfiles (files starting with `.`) in your file manager — make sure it's included.

### Step 3: Enable GitHub Pages

1. Go to your repository → **Settings** tab
2. In the left sidebar, click **Pages**
3. Under **Source**, select **GitHub Actions**
4. Click **Save**

### Step 4: Trigger the deploy

1. Go to the **Actions** tab in your repository
2. You should see a workflow called **Deploy RenderBrief to GitHub Pages**
3. Click it, then click **Run workflow** → **Run workflow**
4. Wait about 60 seconds for it to finish (green checkmark = success)

### Step 5: Open your live app

Visit: `https://YOUR-GITHUB-USERNAME.github.io/renderbrief/`

Replace `YOUR-GITHUB-USERNAME` with your actual GitHub username.

---

## If You Rename the Repository

If you name your repo something other than `renderbrief`, update `vite.config.js`:

```js
base: '/your-repo-name/',
```

Then commit and push — the workflow will rebuild automatically.

---

## Adding Product Images

Place product images inside `public/images/` with these exact filenames:

| Filename | Product |
|---|---|
| `c-chamber.png` | C-Chamber |
| `proox-p110.png` | ProOx P110 |
| `proox-p360.png` | ProOx P360 |
| `proco2-p120.png` | ProCO₂ P120 |
| `proox-c21.png` | ProOx C21 |
| `oxycycler-c42.png` | OxyCycler C42 |
| `oxystreamer.png` | OxyStreamer |
| `oxycycler-gt-series.png` | OxyCycler GT Series |

Export images from the BioSpherix product PDFs. If an image is missing, the app shows "Product image unavailable" — no broken icons.

To upload images to GitHub: go to your repo → `public/images/` folder → click **Add file** → **Upload files**.

---

## File Structure

```
renderbrief/
├── .github/
│   └── workflows/
│       └── deploy.yml          ← Auto-deploys to GitHub Pages on every push
├── public/
│   └── images/                 ← Drop your 8 product PNGs here
├── src/
│   ├── components/
│   │   ├── Dashboard.jsx       ← Screen 1: brief list + stats
│   │   ├── BriefForm.jsx       ← Screen 2: create / edit form (sections A–H)
│   │   ├── BriefDetail.jsx     ← Screen 3: generated brief view
│   │   ├── ComponentReference.jsx ← Screen 4: product reference cards
│   │   └── ProductImg.jsx      ← Shared image component with fallback
│   ├── data/
│   │   └── data.js             ← All product data, sample briefs, constants
│   ├── hooks/
│   │   └── useBriefs.js        ← localStorage CRUD logic
│   ├── App.jsx                 ← Root component + view routing
│   ├── main.jsx                ← React entry point
│   └── styles.css              ← All styles and design tokens
├── index.html
├── vite.config.js              ← Set base path here if you rename the repo
├── package.json
└── README.md
```

---

## Tech Stack

- **React 18** — component UI
- **Vite** — build tool
- **GitHub Actions** — automated build and deploy
- **GitHub Pages** — free static hosting
- **localStorage** — brief data persists in the browser, no backend needed

---

## Built For

AI 201 class project. Designed for Nihar's internal render and design workflow at BioSpherix.
