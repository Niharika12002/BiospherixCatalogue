// src/components/Dashboard.jsx
// Screen 1: Shows all saved render briefs with search, filter, and stats.

import { useState } from 'react'
import {
  productReferences,
  STATUS_OPTIONS,
  PRIORITY_OPTIONS,
  STATUS_COLORS,
  PRIORITY_COLORS,
} from '../data/data.js'

// ─── PRODUCT IMAGE with error fallback ───────────────────────────────────────
function ProductImg({ src, alt }) {
  const [error, setError] = useState(false)
  if (error || !src) {
    return <span className="product-img-fallback">No image</span>
  }
  return (
    <img
      src={src}
      alt={alt}
      style={{ maxHeight: 108, maxWidth: '100%', objectFit: 'contain' }}
      onError={() => setError(true)}
    />
  )
}

// ─── FORMAT DATE ─────────────────────────────────────────────────────────────
function fmtDate(d) {
  if (!d) return '—'
  try {
    return new Date(d + 'T00:00:00').toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
    })
  } catch {
    return d
  }
}

function fmtUpdated(d) {
  if (!d) return ''
  try {
    return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  } catch {
    return ''
  }
}

// ─── STAT CARD ───────────────────────────────────────────────────────────────
function StatCard({ label, value }) {
  return (
    <div className="stat-card">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
    </div>
  )
}

// ─── BRIEF CARD ──────────────────────────────────────────────────────────────
function BriefCard({ brief, onClick }) {
  const firstProd = productReferences.find(p => p.id === (brief.productReferences || [])[0])
  const statusStyle = STATUS_COLORS[brief.status] || STATUS_COLORS['New Request']
  const priorityStyle = PRIORITY_COLORS[brief.priority] || PRIORITY_COLORS['Medium']

  return (
    <div className="brief-card" onClick={onClick}>
      <div className="brief-card-img">
        {firstProd ? (
          <ProductImg src={firstProd.image} alt={firstProd.name} />
        ) : (
          <span className="brief-card-img-placeholder">No system reference selected</span>
        )}
      </div>

      <div className="brief-card-body">
        <div className="brief-card-title">{brief.title || 'Untitled Brief'}</div>
        <div className="brief-card-client">{brief.clientName || 'No client specified'}</div>

        <div className="brief-card-meta">
          <span
            className="badge"
            style={{
              background: statusStyle.bg,
              color: statusStyle.text,
              borderColor: statusStyle.border,
            }}
          >
            {brief.status}
          </span>
          <span
            className="badge"
            style={{
              background: priorityStyle.bg,
              color: priorityStyle.text,
              borderColor: priorityStyle.border,
            }}
          >
            {brief.priority}
          </span>
          {brief.applicationNeed && (
            <span className="badge" style={{ background: '#F7F8FA', color: '#6B7280', borderColor: '#E5E8ED' }}>
              {brief.applicationNeed}
            </span>
          )}
        </div>

        {(brief.gasesNeeded || []).length > 0 && (
          <div className="brief-card-gases">
            {brief.gasesNeeded.map(gas => (
              <span key={gas} className="badge badge-gas">{gas}</span>
            ))}
          </div>
        )}
      </div>

      <div className="brief-card-footer">
        <span className="brief-card-date">Deadline: {fmtDate(brief.deadline)}</span>
        <span className="brief-card-date">Updated {fmtUpdated(brief.updatedAt)}</span>
      </div>
    </div>
  )
}

// ─── EMPTY STATE ─────────────────────────────────────────────────────────────
function EmptyState({ onNew }) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#17233C" strokeWidth="1.8" strokeLinecap="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <line x1="12" y1="18" x2="12" y2="12" />
          <line x1="9" y1="15" x2="15" y2="15" />
        </svg>
      </div>
      <h2>No render briefs yet</h2>
      <p>Create your first render brief to start organizing a custom machine or system request.</p>
      <button className="btn btn-primary btn-lg" onClick={onNew}>
        + New Brief
      </button>
    </div>
  )
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
export default function Dashboard({ briefs, onNewBrief, onOpenBrief }) {
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('All')
  const [priorityFilter, setPriorityFilter] = useState('All')

  const total = briefs.length
  const inProgress = briefs.filter(b => b.status === 'In Progress').length
  const waitingForInfo = briefs.filter(b => b.status === 'Waiting for Info').length
  const readyToRender = briefs.filter(b => b.status === 'Ready to Render').length

  const filtered = briefs.filter(brief => {
    const q = search.toLowerCase()
    const matchesSearch =
      !search ||
      (brief.title || '').toLowerCase().includes(q) ||
      (brief.clientName || '').toLowerCase().includes(q) ||
      (brief.requestSummary || '').toLowerCase().includes(q)
    const matchesStatus = statusFilter === 'All' || brief.status === statusFilter
    const matchesPriority = priorityFilter === 'All' || brief.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const hasFilters = search || statusFilter !== 'All' || priorityFilter !== 'All'

  return (
    <div className="page-content">
      {/* Heading */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 28, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div className="page-title">Render Briefs</div>
          <div className="page-subtitle">Organize custom machine render requests into clear design briefs.</div>
        </div>
        <button className="btn btn-primary btn-lg" onClick={onNewBrief}>
          + New Brief
        </button>
      </div>

      {/* Stats */}
      <div className="stats-row">
        <StatCard label="Total Briefs" value={total} />
        <StatCard label="In Progress" value={inProgress} />
        <StatCard label="Waiting for Info" value={waitingForInfo} />
        <StatCard label="Ready to Render" value={readyToRender} />
      </div>

      {/* Search and filters */}
      <div className="toolbar">
        <div className="search-wrap">
          <svg className="search-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            className="search-input"
            type="text"
            placeholder="Search by title, client, or summary..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          <option value="All">All Statuses</option>
          {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
        </select>

        <select className="filter-select" value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)}>
          <option value="All">All Priorities</option>
          {PRIORITY_OPTIONS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>

        {hasFilters && (
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => { setSearch(''); setStatusFilter('All'); setPriorityFilter('All') }}
          >
            Clear filters
          </button>
        )}
      </div>

      {hasFilters && (
        <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 14 }}>
          Showing {filtered.length} of {total} briefs
        </div>
      )}

      {/* Grid or empty states */}
      {briefs.length === 0 ? (
        <EmptyState onNew={onNewBrief} />
      ) : filtered.length === 0 ? (
        <div className="empty-state" style={{ padding: '48px 40px' }}>
          <h2>No briefs match your filters</h2>
          <p>Try adjusting your search or filter criteria.</p>
        </div>
      ) : (
        <div className="brief-grid">
          {filtered.map(brief => (
            <BriefCard
              key={brief.id}
              brief={brief}
              onClick={() => onOpenBrief(brief.id)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
