// src/App.jsx
// Root component. Manages which screen is shown and passes state to children.
// All brief CRUD lives in useBriefs() — nothing is stored here.

import { useState } from 'react'
import { useBriefs } from './hooks/useBriefs.js'
import Dashboard from './components/Dashboard.jsx'
import BriefForm from './components/BriefForm.jsx'
import BriefDetail from './components/BriefDetail.jsx'
import ComponentReference from './components/ComponentReference.jsx'

// Views:
//   'dashboard'  → Screen 1 — brief list
//   'form'       → Screen 2 — create or edit
//   'detail'     → Screen 3 — read-only brief
//   'reference'  → Screen 4 — component reference

export default function App() {
  const { briefs, addBrief, updateBrief, deleteBrief, duplicateBrief, getBrief } = useBriefs()

  const [view, setView] = useState('dashboard')
  const [activeBriefId, setActiveBriefId] = useState(null)
  const [formMode, setFormMode] = useState('new') // 'new' | 'edit'
  const [preSelectedProduct, setPreSelectedProduct] = useState(null)

  // ── Navigation ──────────────────────────────────────────────────────────────
  function goToDashboard() {
    setView('dashboard')
    setActiveBriefId(null)
    setPreSelectedProduct(null)
  }

  function goToNew() {
    setFormMode('new')
    setActiveBriefId(null)
    setPreSelectedProduct(null)
    setView('form')
  }

  function goToEdit(id) {
    setFormMode('edit')
    setActiveBriefId(id)
    setView('form')
  }

  function goToDetail(id) {
    setActiveBriefId(id)
    setView('detail')
  }

  function goToReference() {
    setView('reference')
  }

  // ── Start a new brief with a product pre-selected (from Reference page) ─────
  function handleNewBriefWithProduct(productId) {
    setFormMode('new')
    setPreSelectedProduct(productId)
    setActiveBriefId(null)
    setView('form')
  }

  // ── Form save ────────────────────────────────────────────────────────────────
  function handleSave(formData) {
    if (formMode === 'edit' && activeBriefId) {
      updateBrief(activeBriefId, formData)
      goToDetail(activeBriefId)
    } else {
      const newId = addBrief(formData)
      goToDetail(newId)
    }
  }

  // ── Duplicate ────────────────────────────────────────────────────────────────
  function handleDuplicate(id) {
    const newId = duplicateBrief(id)
    if (newId) goToDetail(newId)
  }

  // ── Delete ───────────────────────────────────────────────────────────────────
  function handleDelete(id) {
    deleteBrief(id)
    goToDashboard()
  }

  // ── Build initial data for BriefForm ─────────────────────────────────────────
  function getFormInitialData() {
    if (formMode === 'edit' && activeBriefId) {
      return getBrief(activeBriefId)
    }
    if (preSelectedProduct) {
      return { productReferences: [preSelectedProduct] }
    }
    return null
  }

  return (
    <div className="app-shell">
      {/* Header */}
      <header className="app-header">
        <div className="app-header-left">
          <div className="app-logo" onClick={goToDashboard}>
            <div className="app-logo-dot" />
            RenderBrief
          </div>
        </div>
        <nav className="app-nav">
          <button
            className={`nav-btn ${view === 'dashboard' || view === 'form' || view === 'detail' ? 'active' : ''}`}
            onClick={goToDashboard}
          >
            Briefs
          </button>
          <button
            className={`nav-btn ${view === 'reference' ? 'active' : ''}`}
            onClick={goToReference}
          >
            Component Reference
          </button>
          <button
            className="nav-btn"
            onClick={goToNew}
            style={{ color: 'var(--orange)', fontWeight: 700 }}
          >
            + New Brief
          </button>
        </nav>
      </header>

      {/* Screen router */}
      {view === 'dashboard' && (
        <Dashboard
          briefs={briefs}
          onNewBrief={goToNew}
          onOpenBrief={goToDetail}
        />
      )}

      {view === 'form' && (
        <BriefForm
          initialData={getFormInitialData()}
          onSave={handleSave}
          onCancel={goToDashboard}
        />
      )}

      {view === 'detail' && activeBriefId && (
        <BriefDetail
          brief={getBrief(activeBriefId)}
          onEdit={goToEdit}
          onDuplicate={handleDuplicate}
          onDelete={handleDelete}
          onBack={goToDashboard}
        />
      )}

      {view === 'reference' && (
        <ComponentReference onNewBriefWithProduct={handleNewBriefWithProduct} />
      )}
    </div>
  )
}
